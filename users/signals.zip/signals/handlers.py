from paypal.standard.models import ST_PP_COMPLETED
from paypal.standard.ipn.signals import valid_ipn_received

def show_me_the_money(sender, **kwargs):
    print("CONGRATS"*8)
    ipn_obj = sender
    print(ipn_obj.payment_status)
    print(ipn_obj.payer_email)
    print(ipn_obj.receiver_email)
    print(ipn_obj.amount)
    print(ipn_obj.mc_gross)
    if ipn_obj.payment_status == ST_PP_COMPLETED:
        # WARNING !
        # Check that the receiver email is the same we previously
        # set on the `business` field. (The user could tamper with
        # that fields on the payment form before it goes to PayPal)
        if ipn_obj.receiver_email != "hassanbara05@example.com":
            # Not a valid payment
            return

        # ALSO: for the same reason, you need to check the amount
        # received, `custom` etc. are all what you expect or what
        # is allowed.

        # Undertake some action depending upon `ipn_obj`.
        if ipn_obj.custom == "premium_plan":
            price = 0
        else:
            price = 0

        if ipn_obj.mc_gross == price and ipn_obj.mc_currency == 'USD':
            pass
    else:
        pass

valid_ipn_received.connect(show_me_the_money)
